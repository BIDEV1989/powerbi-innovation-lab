# Primary references

Reviewed September 12, 2026. The links document the technologies, not a certification that this generated project has passed Power BI Desktop runtime tests.

- Microsoft: Power BI Desktop projects
  https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-overview
- Microsoft: Project report folder and PBIR format
  https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-report
- Microsoft: Project semantic-model folder (`model.bim` / TMDL)
  https://learn.microsoft.com/en-us/power-bi/developer/projects/projects-dataset
- Microsoft: Public Fabric/Power BI JSON schemas
  https://github.com/microsoft/json-schemas/tree/main/fabric
- HTML Content: Stylesheet property
  https://html-content.com/docs/properties-stylesheet
- HTML Content: Visual editions
  https://html-content.com/docs/visual-editions
- HTML Content: Open-source Lite visual metadata and capabilities used to establish field/format bindings
  https://github.com/dm-p/powerbi-visuals-html-content/tree/1.6.0.0

Original sample code is licensed under the included LICENSE. Microsoft and HTML Content trademarks and third-party products remain their owners' property. No vendor visual binary or font is redistributed.
