# Desktop acceptance — required before public release

This file is deliberately not pre-marked as passed. The artifact generator did not run Power BI Desktop, Power Query, DAX or the HTML Content (lite) runtime.

Record Desktop version: ____________________
Tested by/date: ___________________________

1. Extract the whole package and open `ControlCenter.pbip` in a recent Windows Desktop release with PBIP/PBIR options enabled where required. Confirm no opening/schema errors.
2. Refresh. Confirm all seven tables process without M errors and all 21 measures compile without DAX errors.
3. Confirm HTML Content (lite) loads. If blocked, test Data Explorer and follow organizational approval policy; do not substitute an unapproved visual.
4. On Report Hub, select each workspace. Each should show five reports and three semantic models. Switching workspaces should replace the report panel without opening a new browser/report. Clear selection and verify the selection prompt.
5. Check the Finance no-history case, Quality running case, Research not-refreshable case, and Commercial Analytics failed-model case. Do not count not-refreshable models as failures.
6. On Refresh History with all filters cleared, verify 878 executions, 805 completed, 72 failed, one in progress, 91.8% success, and approximately 9.8 minutes average completed duration.
7. Select a workspace and dates. Confirm all history sections recalculate and a selection without failures has a clear empty message. Current snapshot metadata should not be represented as a historical reconstruction.
8. Inspect Data Explorer. It should contain 878 deduplicated execution rows. Check RunTimestampUTC in Data view to verify the later observation was retained.
9. At Fit to page, inspect all workspace cards, report cards, six recent failures, five slowest models, and the footnote. Check no horizontal clipping. Browser layout previews passed at 1600×1000, but Desktop can differ.
10. Confirm report links remain disabled in this demo. The “Open report” behavior should be tested only after deliberately adding permitted real Power BI URLs in a private copy.
11. Save, close, reopen and refresh. Confirm relative references still work. Publish only to an approved test workspace if Service behavior also needs testing.
12. Before distributing, remove `.pbi` caches/local settings and any real data, URLs, credentials, or sensitivity information introduced during private testing. Share the full folder/ZIP.

No automation or RLS is deployed by this package. Production acceptance requires additional security, API scope, refresh scheduling, empty/error-state, and performance tests.
