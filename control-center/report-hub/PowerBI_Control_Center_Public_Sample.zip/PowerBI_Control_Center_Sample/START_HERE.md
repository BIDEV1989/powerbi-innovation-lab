# Power BI Control Center — Start Here

This is a sanitized community sample built with synthetic metadata. It contains no employer data, tenant IDs, credentials, internal URLs, or production workspace/report identifiers.

## Quick start

1. Extract the complete ZIP. A `.pbip` file is a project pointer, so keep `ControlCenter.pbip`, `ControlCenter.Report`, and `ControlCenter.SemanticModel` together.
2. Open `ControlCenter.pbip` in Power BI Desktop.
3. Refresh the model to load the embedded synthetic sample data.
4. If HTML Content (lite) is not already available in your environment, install/approve that certified AppSource visual before using the HTML pages.
5. Read `Docs/DESKTOP_ACCEPTANCE.md` for the Desktop verification checklist.

## Optional: collect metadata from your own Power BI environment

See `PowerShell/Get-PowerBIControlCenterMetadata.ps1`.

Prerequisite:

```powershell
Install-Module MicrosoftPowerBIMgmt -Scope CurrentUser
```

Run:

```powershell
.\Get-PowerBIControlCenterMetadata.ps1 `
  -OutputFolder "C:\PBI-ControlCenter\Metadata" `
  -AppendSnapshotHistory
```

The script uses interactive Power BI authentication. Do not place credentials or secrets in the script.

## Architecture

Power BI Service → Power BI REST APIs → PowerShell collection → CSV snapshots → SharePoint/file storage → Power BI semantic model → DAX + HTML/CSS Control Center.

Power Automate can replace or complement local scheduling/orchestration where the required connectors/actions are available in your organization.

## Important

The included PBIP was structurally validated offline, but it was not opened in Power BI Desktop in the build environment. Validate it in Desktop before relying on it or redistributing a modified version.
