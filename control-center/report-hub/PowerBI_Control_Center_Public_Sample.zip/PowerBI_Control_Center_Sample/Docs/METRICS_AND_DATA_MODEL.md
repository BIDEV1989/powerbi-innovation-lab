# Metrics and data model

## Table grain and filter direction

- `Workspaces`: one row per synthetic workspace.
- `Semantic Models`: one row per `(WorkspaceId, SemanticModelId)`, with the latest observed refresh state.
- `PBI Control Center Current`: one row per report, enriched with its model's latest state.
- `PBI Refresh History`: one row per `(WorkspaceId, SemanticModelId, RefreshId)`, retaining the latest observation.
- `Calendar`: one row per date across the demo history.
- `Demo Info`: one fixed snapshot timestamp, hidden from the field list.
- `KeyMeasures`: single-row measure home table.

Relationships are single-direction from dimensions to the many side:

```
Workspaces (1) → Semantic Models (*)
Semantic Models (1) → PBI Control Center Current (*)
Semantic Models (1) → PBI Refresh History (*)
Calendar (1) → PBI Refresh History (*)
```

`ModelKey` concatenates workspace/model IDs. No fact-to-fact relationship is used. The report inventory must not be joined to refresh executions to count refreshes: multiple thin reports can share a semantic model.

## Current health

Priority for latest model health:
1. `IsRefreshable = false` → NOT REFRESHABLE.
2. No latest refresh start → NO REFRESH HISTORY.
3. Latest status Completed → HEALTHY.
4. Latest status Failed → REFRESH FAILED.
5. Latest end time absent → IN PROGRESS.
6. Otherwise → UNKNOWN.

HEALTHY means the latest observed refresh completed. It is not a guarantee of business-data quality, freshness against an SLA, or authorization. NO REFRESH HISTORY is not counted as a failure.

Workspace card badge priority: failures, then no history, then in progress, otherwise no failures. The badge gives the most relevant sample exception; percentages and model counts are separate measures.

`Workspace Healthy Rate = Healthy Models / Refreshable Models`. Blank is displayed when the denominator is zero. Current snapshot totals are 24 models: 14 healthy, five failed, two without history, one running, and two not refreshable. Thus the overall rate would be 14/22, not 14/24.

## Refresh-history metrics

- Refresh executions: distinct execution rows after deduplication.
- Completed / failed: matching terminal status in selected filter context.
- In progress: Unknown/InProgress status with blank EndTimeUTC.
- Success rate: completed / (completed + failed); blank when no terminal rows exist.
- Average duration: mean DurationSeconds of Completed rows / 60.
- Recent failures: six most recent failed executions; ties broken by RefreshId.
- Slowest models: five models with highest average completed-refresh duration in selected context.

The distribution bars use all executions as their denominator. The success-rate KPI uses terminal executions only; they are intentionally different denominators.

## Snapshot reconstruction

The raw fixture has 1,755 observations and 878 unique executions. Two observations may describe the same execution at different capture times. Some first observations are in progress, while later ones are completed/failed. Sorting by capture timestamp and retaining the latest prevents stale state from overwriting the final result.

M pipeline:
`Sample Raw Refreshes → sort latest capture → Table.Buffer → Table.Distinct(composite execution key) → ModelKey + RefreshDate`.

A separate model-level step chooses the latest execution by StartTimeUTC and RefreshId. Never select the “latest” status alphabetically and never confuse a snapshot time with an execution time.

## Important sample limits

All report/model “Import/DirectQuery” source-mode labels in the inventory are fictional metadata. The sample semantic model itself uses Import mode with inline M sources. There is no DirectQuery backend.

The sample covers intra-workspace report/model assignments. Cross-workspace thin-report lineage needs explicit real-source mapping before production use.

Dates, durations, owners, errors and schedules are synthetic. Matching the sample totals verifies data consistency, not the permissions or correctness of a production collection script.
