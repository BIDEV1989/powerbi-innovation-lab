# Power BI Control Center — Shareable Sample

A reconstructed, metadata-driven Control Center with **synthetic data only**.
It demonstrates the workspace/report hub and historical refresh monitoring from the original approach without distributing a company PBIX, credentials, tenant identifiers, or internal report links.

**Validation status:** project structure, model bindings, sample-data integrity, and browser-rendered HTML layouts have been checked. **The package has not been opened or executed in Windows Power BI Desktop.** Complete `Docs/DESKTOP_ACCEPTANCE.md` before publishing or presenting this as a tested template. M and DAX need that Desktop runtime check.

## Open the project

1. Extract the **entire ZIP** to a short local path, such as `C:\PBI\ControlCenter`. Keep the report and semantic-model folders together.
2. Use a current Windows **Power BI Desktop** release (not Desktop for Report Server). In **File → Options and settings → Options → Preview features**, enable **Power BI Project (.pbip) save option** and **Store reports using enhanced metadata format (PBIR)** if your release exposes those options. Restart Desktop after changing preview settings.
3. Open **`ControlCenter.pbip`**. The `.pbip` is a pointer; it is not a standalone replacement for the accompanying folders.
4. Click **Home → Refresh** once. There is no data cache in the package. The model loads its data from inline Power Query tables, so no SharePoint connection, tenant credentials, API token, gateway, or file-path edits are needed.
5. The main pages reference **HTML Content (lite)** from AppSource. Desktop normally resolves public visuals automatically. If it does not, use **Get more visuals** to add the certified **HTML Content (lite)** visual. Organizational policies may block it; this sample cannot override those policies.
6. Select a workspace on **Report Hub**. Use the workspace/date slicers on **Refresh History**. **Data Explorer** and **Read Me** use native visuals and are useful if the HTML visual is unavailable.

The model itself has no external data-source dependency. Resolving/installing the AppSource visual may require internet access and permitted access to AppSource.

## Included pages

| Page | Purpose |
|---|---|
| Report Hub | Workspace cards at left, selected-workspace heading and report cards at right. Selection is passed through Power BI filter context. |
| Refresh History | Execution counts, completed/failed/running states, success rate, average completed duration, latest six failures, and five slowest models. |
| Data Explorer | Native table to inspect and export deduplicated refresh executions, with workspace/date filters. |
| Read Me | In-report setup, architecture, scope, and validation notes. |

The history summaries deliberately show a bounded number of detail rows. The complete history remains in the model and on Data Explorer. No claim is made that the layout will remain scroll-free after adding an arbitrary number of workspaces or reports.

## Synthetic sample

Snapshot time: **September 12, 2026, 12:00 UTC**. History covers **August 16–September 12, 2026**.

| Item | Expected total |
|---|---:|
| Workspaces | 8 |
| Reports | 40 |
| Semantic models | 24 |
| Raw refresh observations | 1,755 |
| Unique refresh executions | 878 |
| Repeated observations removed | 877 |
| Completed executions | 805 |
| Failed executions | 72 |
| In-progress executions | 1 |
| Success rate | 91.8% |

Several reports share a model. Refresh executions are counted at **model execution grain**, never multiplied by the number of reports using that model.

Model-level latest health includes 14 healthy, five failed, two without history, one in progress, and two not refreshable. These are current snapshot states, not counts of every failure in the history.

Names, identifiers, email addresses, refresh records, and error text are invented. Owner addresses use `example.com`. Report URLs are blank on purpose; the sample displays **Demo report · no live link** instead of pretending a synthetic report exists in the Service.

## Folder structure

```
ControlCenter.pbip
ControlCenter.Report/             PBIR report definition and visual bindings
ControlCenter.SemanticModel/      model.bim (TMSL) and model properties
Source/DAX/                      Individual numeric and HTML measures
Source/CSS/                      Workspace, report, and refresh stylesheets
Source/PowerQuery/               Inline sample sources and transformation logic
SampleData/                      CSV exports of raw and transformed demo data
Docs/                            Architecture, metrics, Desktop checks, previews
Validation/                      Fixtures, expected results, offline validation
LICENSE                          Original sample code license
```

**Model format:** this sample uses `model.bim`, a supported semantic-model definition format within PBIP, rather than TMDL. Power BI can save the project in the format supported by your Desktop release.

The CSV files are provided for inspection and reuse. Editing a CSV **does not change the default report**: the default source is embedded in `model.bim` as inline M. Replace the M source explicitly to use files or your own SharePoint/API exports.

## HTML setup and maintenance

| Visual | Values/content | Granularity/sampling | Stylesheet |
|---|---|---|---|
| Workspace cards | `KeyMeasures[Control Center - Workspace HTML]` | `Workspaces[WorkspaceName]` | `Source/CSS/workspaces.css` |
| Selected-workspace heading | `KeyMeasures[Control Center - Reports Header HTML]` | None | `Source/CSS/reports.css` |
| Report cards | `KeyMeasures[Control Center - Reports HTML]` | None | `Source/CSS/reports.css` |
| Refresh dashboard | `KeyMeasures[Control Center - Refresh History HTML]` | None | `Source/CSS/refresh.css` |

The public visual identifier referenced in the report is `htmlContent443BE3AD55E043BF878BED274D3A6865`. The package does not redistribute a third-party `.pbiviz` binary or fonts.

Stylesheets are already serialized into each visual's **Stylesheet** property, without `<style>` tags. Measures generate HTML and dynamic values only, except dynamic bar-width/link attributes. For future edits, paste the updated CSS into the relevant visual's Stylesheet box. The files under `Source` are readable copies, not live file links. Changing them alone will not update an already-open report.

For workspace selection, **Cross-filtering** is enabled on the workspace HTML visual and unselected-item transparency is disabled. The page specifies workspace-to-report **DataFilter** interactions. The right-hand measures check `HASONEVALUE(Workspaces[WorkspaceId])`. If no single workspace is selected, a selection prompt appears rather than rendering all reports.

If the report cards do not respond in Desktop, verify the field mapping above and **Edit interactions → Filter** from the workspace visual to the report heading/cards. This needs a Desktop smoke test because the custom-visual runtime is not available in the generation environment.

## Metrics and history

Read `Docs/METRICS_AND_DATA_MODEL.md` for exact definitions. Two distinctions matter:

- Workspace healthy percentage is **healthy refreshable models / refreshable models**. Not-refreshable models are excluded. Missing history and running states are not failures, but are also not counted as healthy.
- History success rate is **Completed / (Completed + Failed)** for the selected scope. An in-progress execution does not count as failed or completed. Average duration includes completed refreshes only.

Overlapping observations are sorted by `RunTimestampUTC` descending, buffered, and deduplicated by `WorkspaceId + SemanticModelId + RefreshId`. An older running observation must not displace a newer terminal result. The sample includes this case.

Calendar filters affect the **history fact table**, not the current inventory snapshot. All displayed times are UTC. The fixed demo date is intentional; refreshing next month will not turn the sample into live data.

## What this sample does not claim to implement

No live API extraction, PowerShell task, Power Automate cloud flow, gateway, writeback, usage/activity analytics, tenant-wide permission audit, ownership certification, automatic anomaly detection, or RLS is deployed by opening this project. No cloud resources are created and no messages are sent.

The original approach used PowerShell and Power BI REST APIs with SharePoint storage. Cloud orchestration and security are separate implementation steps. This sample replaces external data collection with embedded synthetic observations so readers can inspect the report and calculation design safely.

Before connecting real data, establish approved API scope, authentication, scheduled ingestion, permissions, RLS where needed, and refresh schedules. Do not include secrets in a public PBIP. Desktop viewing of this embedded sample does not require provisioning Fabric capacity; publishing and sharing use your organization's normal licensing and governance.

## Sharing safely

Share **this entire ZIP/folder**, not an internal PBIX and not `ControlCenter.pbip` alone. The two PNGs in `Docs` are **browser-rendered HTML layout previews using synthetic fixtures**, not screenshots captured in Power BI Desktop. They must not be presented as customer screenshots.

Suggested description: “Power BI Control Center sample project with synthetic inventory and refresh history. Includes separate HTML/DAX, CSS, Power Query, and a refresh-deduplication example.” Add a Desktop-tested version/build number only after completing the acceptance checklist.

## Validation

With Python 3 installed, run:

```
python Validation/validate_sample.py
```

This performs offline checks; it does **not** evaluate DAX, Power Query, or the Power BI custom visual. `Validation/validation_report.json` records the checks and remaining Desktop acceptance gate.

Official documentation used for the project format and visual is listed in `Docs/REFERENCES.md`.
