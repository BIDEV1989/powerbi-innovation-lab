"""Offline consistency checks. This does NOT execute Power BI, DAX, M, or vendor visuals."""
from __future__ import annotations
import csv
import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CHECKS: list[dict[str, str]] = []

def check(name: str, condition: bool, detail: str = '') -> None:
    CHECKS.append({'check': name, 'status': 'PASS' if condition else 'FAIL', 'detail': detail})

def load(path: str):
    return json.loads((ROOT / path).read_text(encoding='utf-8'))

def key(row):
    return (row['WorkspaceId'], row['SemanticModelId'], row['RefreshId'])

def walk(obj):
    if isinstance(obj, dict):
        yield obj
        for value in obj.values():
            yield from walk(value)
    elif isinstance(obj, list):
        for value in obj:
            yield from walk(value)

def expression_balanced(text: str) -> bool:
    """Lexical delimiter check only; not a language parser or engine validation."""
    i, stack, quoted = 0, [], False
    pairs = {')': '(', ']': '[', '}': '{'}
    while i < len(text):
        ch = text[i]
        if ch == '"':
            if quoted and i + 1 < len(text) and text[i+1] == '"':
                i += 2
                continue
            quoted = not quoted
        elif not quoted:
            if ch in '([{':
                stack.append(ch)
            elif ch in ')]}':
                if not stack or stack.pop() != pairs[ch]:
                    return False
        i += 1
    return not quoted and not stack

def main() -> int:
    for name in ['ControlCenter.pbip', 'ControlCenter.Report/definition.pbir',
                 'ControlCenter.SemanticModel/definition.pbism', 'ControlCenter.SemanticModel/model.bim',
                 'README.md', 'LICENSE', 'Docs/DESKTOP_ACCEPTANCE.md']:
        check('Required file: '+name, (ROOT/name).is_file())
    parsed = 0
    for path in ROOT.rglob('*'):
        if path.suffix in {'.json', '.pbip', '.pbir', '.pbism', '.bim'}:
            try:
                json.loads(path.read_text(encoding='utf-8'))
                parsed += 1
            except (ValueError, UnicodeError) as exc:
                check('JSON parse: '+str(path.relative_to(ROOT)), False, str(exc))
    check('Project JSON parses', not any(c['status']=='FAIL' for c in CHECKS), f'{parsed} JSON-format files')
    project = load('ControlCenter.pbip')
    report_path = ROOT/project['artifacts'][0]['report']['path']
    ref = json.loads((report_path/'definition.pbir').read_text())
    model_path = (report_path/ref['datasetReference']['byPath']['path']).resolve()
    check('Relative report/model references exist', report_path.is_dir() and (model_path/'model.bim').is_file())
    model = json.loads((model_path/'model.bim').read_text())['model']
    tables = {t['name']: t for t in model['tables']}
    fields = {name: {c['name'] for c in table['columns']} for name,table in tables.items()}
    measures = {m['name']:m for t in tables.values() for m in t.get('measures',[])}
    check('Model table/measure/relationship counts', len(tables)==7 and len(measures)==21 and len(model['relationships'])==4)
    for table in tables.values():
        expr = '\n'.join(table['partitions'][0]['source']['expression'])
        check('M source matches readable copy: '+table['name'], expr==(ROOT/'Source/PowerQuery'/f'{table["name"]}.pq').read_text())
        check('M delimiters: '+table['name'], expression_balanced(expr), 'Lexical check only')
    for m in measures.values():
        expr = '\n'.join(m['expression'])
        check('DAX source matches model: '+m['name'], (ROOT/'Source/DAX'/f'{m["name"]}.dax').read_text().strip()==(m['name']+' =\n'+expr).strip())
        check('DAX delimiters: '+m['name'], expression_balanced(expr), 'Lexical check only')
    check('No model RLS claimed or configured', not model.get('roles'))
    all_m = '\n'.join((ROOT/'Source/PowerQuery'/p.name).read_text() for p in (ROOT/'Source/PowerQuery').glob('*.pq'))
    check('No external M data-source calls', not any(token in all_m for token in ['File.Contents(', 'Folder.Files(', 'Web.Contents(', 'SharePoint.Files(', 'SharePoint.Tables(', 'Sql.Database(']))
    check('Latest-capture deduplication explicitly implemented', all(x in (ROOT/'Source/PowerQuery/PBI Refresh History.pq').read_text() for x in ['Order.Descending','Table.Buffer','Table.Distinct','WorkspaceId','SemanticModelId','RefreshId']))
    page_order = load('ControlCenter.Report/definition/pages/pages.json')
    check('Page order / active page', len(page_order['pageOrder'])==4 and page_order['activePageName'] in page_order['pageOrder'])
    all_names = []
    custom_count = 0
    for page_name in page_order['pageOrder']:
        base = report_path/'definition/pages'/page_name
        page = json.loads((base/'page.json').read_text())
        visuals = [json.loads(p.read_text()) for p in (base/'visuals').glob('*/visual.json')]
        names = {v['name'] for v in visuals}
        check('Unique visual IDs on '+page_name,len(names)==len(visuals))
        for v in visuals:
            all_names.append(v['name'])
            pos=v['position']
            check('Visual within page: '+v['name'], pos['x']>=0 and pos['y']>=0 and pos['x']+pos['width']<=page['width']+0.01 and pos['y']+pos['height']<=page['height']+0.01)
            for item in walk(v.get('visual',{}).get('query',{})):
                for typ in ['Column','Measure']:
                    if typ in item and 'Expression' in item[typ]:
                        f=item[typ]; entity=f['Expression']['SourceRef']['Entity']; prop=f['Property']
                        valid=prop in fields.get(entity,set()) if typ=='Column' else entity in tables and prop in {m['name'] for m in tables[entity].get('measures',[])}
                        check('Bound '+typ+': '+entity+'.'+prop,valid)
            if v['visual']['visualType'].startswith('htmlContent'):
                custom_count+=1
                props=v['visual']['objects']['stylesheet'][0]['properties']
                css=props['stylesheet']['expr']['Literal']['Value'][1:-1].replace("''", "'")
                check('CSS matches maintained source: '+v['name'], css in [(ROOT/'Source/CSS'/n).read_text() for n in ['workspaces.css','reports.css','refresh.css']])
        for interaction in page.get('visualInteractions',[]):
            check('Valid interaction on '+page_name,interaction['source'] in names and interaction['target'] in names)
    check('30 visuals, 4 HTML visuals',len(all_names)==30 and custom_count==4)
    fixture=load('Validation/sample_fixture.json'); expected=load('Validation/expected_metrics.json')
    rows=fixture['history']; raw=fixture['raw']
    check('Expected raw/dedup counts',len(raw)==1755 and len(rows)==878)
    check('Refresh execution keys unique',len({key(r) for r in rows})==len(rows))
    bykey=defaultdict(list)
    for r in raw: bykey[key(r)].append(r)
    changed=0
    for row in rows:
        latest=max(bykey[key(row)],key=lambda r:r['RunTimestampUTC'])
        check('Latest observation retained: '+str(row['RefreshId']),all(row[k]==v for k,v in latest.items()))
        if len({x['RefreshStatus'] for x in bykey[key(row)]})>1:changed+=1
    check('Fixture includes status transitions',changed>0,f'{changed} executions have different statuses across captures')
    states=Counter(r['RefreshStatus'] for r in rows)
    check('Terminal/running totals',states=={'Completed':805,'Failed':72,'Unknown':1})
    check('Success rate denominator',abs(states['Completed']/(states['Completed']+states['Failed'])-expected['success_rate_completed_plus_failed'])<1e-12)
    health=Counter(m['HealthStatus'] for m in fixture['model_current'])
    check('Latest model health totals',dict(health)==expected['latest_model_health'])
    workspace_ids={w['WorkspaceId'] for w in fixture['workspaces']}
    model_keys={m['ModelKey'] for m in fixture['model_current']}
    check('Workspace one-side key unique',len(workspace_ids)==len(fixture['workspaces'])==8)
    check('Model one-side key unique',len(model_keys)==len(fixture['model_current'])==24)
    check('Report count and unique keys',len(fixture['reports'])==len({r['ReportId'] for r in fixture['reports']})==40)
    check('No orphan model/workspace keys',all(m['WorkspaceId'] in workspace_ids for m in fixture['models']))
    check('No orphan report/history model keys',all(r['ModelKey'] in model_keys for r in fixture['current']+fixture['history']))
    check('Five reports/three models per workspace',all(sum(r['WorkspaceId']==w for r in fixture['reports'])==5 and sum(m['WorkspaceId']==w for m in fixture['models'])==3 for w in workspace_ids))
    check('Demo report links blank',all(r['ReportURL'] is None for r in fixture['reports']))
    check('Demo owner domains',all(m['SemanticModelOwner'].endswith('@example.com') for m in fixture['models']))
    for rel in model['relationships']:
        check('Relationship exists: '+rel['name'],rel['fromColumn'] in fields[rel['fromTable']] and rel['toColumn'] in fields[rel['toTable']] and rel['crossFilteringBehavior']=='oneDirection')
    csvmap={'workspaces.csv':'workspaces','reports.csv':'reports','semantic_models.csv':'models','refresh_snapshots.csv':'raw','refresh_history.csv':'history','current_report_catalog.csv':'current','semantic_models_current.csv':'model_current'}
    for name,fkey in csvmap.items():
        with (ROOT/'SampleData'/name).open(encoding='utf-8-sig',newline='') as stream: data=list(csv.DictReader(stream))
        check('CSV row count: '+name,len(data)==len(fixture[fkey]))
    check('Browser layout has no overflow at 1600x1000',all(not value for value in load('Validation/layout_checks.json').values()),'HTML fixture layout only, not Power BI Desktop runtime')
    # Public-data allowlist: synthetic owners and disabled sample URLs only.
    for r in fixture['current']:
        check('Public catalog row: '+r['ReportId'],r['ReportURL'] is None and r['SemanticModelOwner'].endswith('@example.com'))
    check('No private cache, credentials or vendor binaries',not any(p.suffix in {'.abf','.pbiviz','.ttf','.otf'} or p.name=='localSettings.json' for p in ROOT.rglob('*')))
    failed=[c for c in CHECKS if c['status']=='FAIL']
    summary={'scope':'Offline structural/data/lexical/layout checks, NOT full schema or Desktop runtime validation','checks':len(CHECKS),'passed':len(CHECKS)-len(failed),'failed':len(failed),'power_bi_desktop':'NOT RUN — follow Docs/DESKTOP_ACCEPTANCE.md','dax_and_m_runtime':'NOT RUN','checks_detail':CHECKS}
    (ROOT/'Validation/validation_report.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(f'{len(CHECKS)-len(failed)}/{len(CHECKS)} offline checks passed.')
    for c in failed:print('FAIL:',c['check'],c['detail'])
    print('Power BI Desktop / DAX / M runtime: NOT RUN.')
    return 1 if failed else 0

if __name__=='__main__':
    try:
        sys.exit(main())
    except (OSError,ValueError,KeyError) as exc:
        print('Validation could not finish:',exc,file=sys.stderr)
        sys.exit(2)
